/*
 * 2� esempio: classi astratte
 * 
 * Una classe astratta (o generica) non rappresenta nessun oggetto concreto ma fornisce un insieme di caratteristiche (attributi e metodi) comuni a tutte le classi figlie ereditate da essa.
 * 
 * N.B.: una classe astratta per come � definita, non pu� essere istanziata. 
 * Nell'esempio seguente, Animale � una classe astratta che verr� poi specializzata nelle classi (concrete) Mucca, Cavallo, Pecora, Gallo, ... 
 * La classe Animale contiene le caratteristiche comuni a tutti gli animali, come il colore e la possibilit� di emettere un verso: questo consentir� di dichiarare oggetti generici di classe Animale e decidere poi a tempo di esecuzione se saranno mucche, cavalli, ecc...
 * Una classe astratta pu� contenere tutto quanto si pu� mettere in una classe concreta quindi anche costruttori (sebbene questi saranno utilizzati solo dalle classi derivate).
 * Il metodo Verso � un metodo astratto cio� non � implementato (e non deve esserlo) nella classe Animale ma sar� definito nelle classi derivate.
 * 
 * N.B.: se una classe contiene un metodo astratto, deve essere dichiarata come astratta. Le classi derivate da una classe astratta devono implementare tutti i metodi astratti delle classe padre.
 */

using System;
using System.Media;

namespace Animali
{
    abstract class Animale
    {
        private static SoundPlayer player = new SoundPlayer();

        protected void Play(string fileAudio)
        {
            player.SoundLocation = fileAudio;
            player.PlaySync();
        }

        public string Colore { get; set; }

        public abstract string Verso();

        public abstract int Zampe { get; } // propriet� astratta
    }
		
    class Asino : Animale
    {        
        public override string Verso()
        {
            Play("asino.wav");
            return "hi! ho!";
        }

        public override int Zampe => 4;
    }
		
    class Cavallo : Animale
    {        
        public override string Verso()
        {
            Play("cavallo.wav");
            return "hii! hii!";
        }

        public override int Zampe => 4;
    }
		
    class Gallo : Animale
    {        
        public override string Verso()
        {
            Play("gallo.wav");
            return "chichirichii!";
        }

        public override int Zampe => 2;
    }
    
    class Gatto : Animale
    {        
        public override string Verso()
        {
            Play("gatto.wav");
            return "miao!";
        }

        public override int Zampe => 4;
    }

    class Maiale : Animale
    {        
        public override string Verso()
        {
            Play("maiale.wav");
            return "oink! oink!";
        }

        public override int Zampe => 4;
    }

    class Mucca : Animale
    {
        public override string Verso()
        {
            Play("mucca.wav");
            return "muuu! muuu!";
        }

        public override int Zampe => 4;
    }

    class Papera : Animale
    {
        public override string Verso()
        {
            Play("papera.wav");
            return "qua! qua!";
        }

        public override int Zampe => 4;
    }
}